package com.dio.jpa.jpabasico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpabasicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpabasicoApplication.class, args);
	}

}
