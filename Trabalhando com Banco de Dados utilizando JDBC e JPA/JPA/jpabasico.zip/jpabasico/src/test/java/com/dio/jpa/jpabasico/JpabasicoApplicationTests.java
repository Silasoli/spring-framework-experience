package com.dio.jpa.jpabasico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpabasicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
